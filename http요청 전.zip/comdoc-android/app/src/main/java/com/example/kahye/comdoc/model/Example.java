package com.example.kahye.comdoc.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Kahye on 2015. 10. 7..
 */
public class Example {
    String name;
    String age;
    int photoId;

   public  Example(String name, String age, int photoId) {
        this.name = name;
        this.age = age;
        this.photoId = photoId;
    }
}
