package com.example.kahye.comdoc;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Kahye on 2015. 10. 7..
 */
class Example {
    String name;
    String age;
    int photoId;

    Example(String name, String age, int photoId) {
        this.name = name;
        this.age = age;
        this.photoId = photoId;
    }
}

private List<Example> example;

    // This method creates an ArrayList that has three Person objects
// Checkout the project associated with this tutorial on Github if
// you want to use the same images.
    private void initializeData(){
        example = new ArrayList<>();
        example.add(new Example("Emma Wilson", "23 years old", R.drawable.));
        example.add(new Example("Lavery Maiss", "25 years old", R.drawable.lavery));
        example.add(new Example("Lillie Watts", "35 years old", R.drawable.lillie));
    }